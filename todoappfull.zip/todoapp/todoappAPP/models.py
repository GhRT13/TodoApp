from django.db import models

# Create your models here.
class Tarea (models.Model):
    id_tarea = models.BigAutoField(primary_key=True)
    nombre = models.CharField(max_length=50,verbose_name='Nombre')
    descripcion = models.CharField(max_length=50,verbose_name='Descripcion')
    fecha = models.DateField(null= True)
    terminado = models.BooleanField(default=True, verbose_name='Terminado')  # Agregando el campo booleano
    

    def __str__(self):
        return self.nombre
