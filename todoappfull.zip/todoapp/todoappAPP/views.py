from django.shortcuts import render, redirect
from todoappAPP.models import *
from todoappAPP.form import *

# Create your views here.
def tareas(request):
    tareas = Tarea.objects.all()
    
    return render(request,'tareas.html',{"tareas":tareas})



def insertar_tarea(request):
    
    form=Formulario_Tarea(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('tareas')
    else: print('Error')
    return render(request, 'insertarTarea.html',{'miformulario':form})


def editar_tarea (request, id_tarea):
    tarea = Tarea.objects.get(id_tarea=id_tarea)
    formulario = Formulario_Tarea(instance=tarea)
    if request.method == 'POST':
        formulario = Formulario_Tarea(request.POST, instance=tarea)
        if formulario.is_valid():
            formulario.save()
            return redirect('tareas')
    return render(request, 'insertarTarea.html', {'miformulario': formulario})

def eliminar_tarea(request,id_tarea):
    
    tarea= Tarea.objects.get(pk = id_tarea)
    
    tarea.delete()
    
    return redirect("tareas")
