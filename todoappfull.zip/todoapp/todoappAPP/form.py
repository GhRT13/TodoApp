
from django import forms
from todoappAPP.models import*
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit, Field


class Formulario_Tarea(forms.ModelForm):
    class Meta:
        model=Tarea
        fields='__all__'

    def __init__(self, *args, **kwargs):
        super(Formulario_Tarea, self).__init__(*args, **kwargs)
        self.fields['fecha'].widget.input_type = 'date'

 