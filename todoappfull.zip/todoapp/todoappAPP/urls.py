from django.urls import path, include
from todoappAPP import views

urlpatterns = [
    path('', views.tareas, name="tareas"),
    path('insertarTarea/', views.insertar_tarea,name="insertarTarea"),
    path('editarTarea/<int:id_tarea>', views.editar_tarea,name="editarTarea"),
    path('eliminarTarea/<int:id_tarea>', views.eliminar_tarea,name="eliminarTarea"),
    

    

]