from django.contrib import admin

# Register your models here.
from django.contrib import admin
from todoappAPP.models import *




class Tarea_admin(admin.ModelAdmin):
    list_display = ("nombre", "descripcion","fecha","terminado")
    search_fields = ("nombre","terminado")
    list_filter = ("fecha", "nombre")


admin.site.register(Tarea, Tarea_admin)
